import crypto
import os

sent = 'Dialga27890'

salt = os.environ.get('salt')
password = crypt.METHOD_CRYPT(sent, 'salt')
print(password)