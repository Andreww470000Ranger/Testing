import re

pattern = "do you remember .*"
message = "do you remember when i ate strawberries in the garden?" 
match = re.search(pattern, message)

if match:
	print("string matches!!")

match.group(0)
'what would happen if bots took over the world'

match.group(1)
'bots will take the world'

def swap_pronouns(phrase):
	if 'I' in phrase:
		return re.sub('I', 'you', phrase)
		if 'my' in phrase:
			return re.sub('my', 'your', phrase)
	else:
		return phrase

swap_pronouns("I walk my dog")