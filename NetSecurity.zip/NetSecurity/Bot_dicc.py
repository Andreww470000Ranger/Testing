#****************Comando****************#
response = {
	"What's your name?": "My name is EchoBot with Python"
	"What's the weather today:" : "It's sunny!"
}

def respond(message):
	if message in response:
		retrun response[message]

respond("What's your name?")

#****************Inteligencia Artificial****************#
response = {
	"What's the weather today:" : "It's {}! today"
}

def respond(message):
	if message in response:
		return (response[message].format(weather_today))

respond("What's the weather today?")
#****************Seleccion aleatoria/Inteligencia Artificial****************#
response = {
	"What's your name?" : [
	"My name is EchoBot"
	"They call me EchoBot"
	"The name's Bot, EchoBot"
	]
}

import random

def respond(message):
	if message in response: 
		return(random.choice(response[message]))
#****************Seleccion aleatoria/Inteligencia Artificial****************#
name = "Greg"
weather = "Cloudy"

responses = {
	"What's your name?" : "My name is {0}".format(name),
	"What's the weather today?" : "The weather is {0}".format(weather),
	"default" : "default message"
}

def respond(message):
	if message in responses:
		bot_message = responses[message]
	else:
		bot_message = responses["default"]
	return (bot_message)
#*******************Seleccion por partes/Inteligencia Artificial*************#
import random

name = "Greg"
weather = "Cloudy"

responses = {
	"What's your name?" : [
	"My name is {0}".format(name),
	"They call me {0}".format(name),
	"I go by {0}".format(name)
	],
	"What's the weather today?" : [
	"The weather is {0}".format(weather),
	"It's {0} today".format(weather)
	]
	"default" : ["default message"]
}

def respond(message):
	if message in responses:
		bot_message = random.choice(responses[message])
	else:
		bot_message = random.choice(responses["default"])
	return (bot_message)
#*******************Seleccion por Ingreso Aleatorio/Inteligencia Artificial*************#
import random


responses = {
	"question" : "question"
	"statement" : "statement"
}

def respond(message):
	if message.endswith("?"):
		return random.choice(responses["question"])
	return( random.choice(responses["statement"]))

send_message("What's today's weather?")
send_message("What's today's weather?")

send_message("I love building chat bots")
send_message("I love building chat bots")
